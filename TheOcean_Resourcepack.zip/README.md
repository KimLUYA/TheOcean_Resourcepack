# TheOcean_Resourcepack
마인크래프트 오션 서버 리소스팩

제작자의 허락 없는 2차 배포/수정/사용을 금지합니다.

제작자: 김루야

연락처: jumiluya@naver.com

개인 포트폴리오: https://kimluya.notion.site/f80528fcf7264faea879802df3d3a065
